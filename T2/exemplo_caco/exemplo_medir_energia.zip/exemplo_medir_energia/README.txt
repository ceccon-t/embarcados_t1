*******************************
Os arquivos energia.c e energia.h são os arquivos com o código biblioteca do RALP,
e o arquivo exemplo.c é um código de exemplo de como usá-los.

Para compilar a aplicação usando a lib, use o comando:
$ gcc exemplo.c energia.c -o mmatriz

onde:
  "exemplo.c" é o seu arquivo
  "energia.c" é o arquivo com o código da lib do RAPL (deve estar no mesmo diretório)
  "mmatriz" é o nome do arquivo executável de saida

*******************************


